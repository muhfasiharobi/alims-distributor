<?php
	switch($_GET['execute'])
	{
		default:
			default_customer_report();
		break;
		
	}
?>
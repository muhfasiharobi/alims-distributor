<?php
	switch($_GET['execute'])
	{
		default:
			default_infographic_purchase_platform();
		break;
	}
?>
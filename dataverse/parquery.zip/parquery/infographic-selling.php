<?php
	switch($_GET['execute'])
	{
		default:
			default_infographic_selling_platform();
		break;
	}
?>
<?php
	switch($_GET['execute'])
	{
		default:
			default_infographic_selling_agent_platform();
		break;
	}
?>